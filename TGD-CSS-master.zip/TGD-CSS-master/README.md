﻿# 일하는 우애나

## CSS
http://tgd.kr/nanajam777/ 에서 사용되는 커스텀 스타일 시트 입니다.

## Emotes
제가 그린 구독이모티콘과 배지가 공개되어 있습니다.
그 외의 이모티콘은 [여기](https://twitchemotes.com/channels/150664679)에서 확인하세요!

* 물방울
* 광어

## Images
CSS나 기타 소스에 사용되는 이미지들이 모여있는 곳입니다.

## 제작자
* http://twitch.tv/ingether